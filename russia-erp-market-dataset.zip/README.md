# Russia ERP Software Market Dataset

This dataset is built using publicly available summary information from the Russia ERP Software Market report by NextMSC.

## Files Included
- **market_overview.csv** – Key market values (2024, 2025, 2030).
- **segmentation.csv** – Segmentation by component, deployment, business function, end-user, and industry vertical.
- **metadata.json** – Source metadata and extraction details.

## Source
Russia ERP Software Market – NextMSC (public summary).

## Usage
Suitable for:
- Market trend research
- Academic studies
- Modeling, visualizations, and data analysis

## Disclaimer
This dataset includes only publicly accessible summary-level information. No proprietary content or paid report data is included.
